#ifndef __DHCP_H__
#define __DHCP_H__

int do_dhcp(char *iname);
#endif //__DHCP_H__